// Title.js
import React from "react";

function Title() {
  return <h1>Welcome to Our Store</h1>;
}

export default Title;
